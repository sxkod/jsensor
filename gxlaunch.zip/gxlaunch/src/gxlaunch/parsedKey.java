package gxlaunch;

import java.util.ArrayList;

/**
 *
 * @author skodela
 */
public class parsedKey {
    String key;
    ArrayList<Integer> vals;
    ArrayList<Character> modes;
    parsedKey(){
        vals=new ArrayList<Integer>();
        modes= new ArrayList<Character>();
    }
}
